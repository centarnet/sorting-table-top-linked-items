<?php
// public.php

// Umetanje like i dislike dugmadi te brojača u zadnji stupac tablice
function sorting_table_add_buttons($column, $post_id) {
    sorting_table_display_buttons($column, $post_id);
}
add_action('manage_posts_custom_column', 'sorting_table_add_buttons', 10, 2);

// Funkcija za prikazivanje like i dislike dugmadi te brojača
function sorting_table_display_buttons($column, $post_id) {
    if ($column === 'sorting_table_likes') {
        $likes = get_post_meta($post_id, 'likes', true);
        $dislikes = get_post_meta($post_id, 'dislikes', true);
        $current_user = wp_get_current_user();

        $like_class = 'sorting-table-like';
        $dislike_class = 'sorting-table-dislike';

        // Provjera je li korisnik već likeao ili dislikeao
        if (is_user_logged_in() && get_user_meta($current_user->ID, 'sorting_table_liked_' . $post_id, true)) {
            $like_class .= ' active';
            $dislike_class .= ' disabled';
        } elseif (is_user_logged_in() && get_user_meta($current_user->ID, 'sorting_table_disliked_' . $post_id, true)) {
            $like_class .= ' disabled';
            $dislike_class .= ' active';
        }

        // Ispisivanje like i dislike dugmadi te brojača
        echo '<div class="sorting-table-buttons">';
        echo '<button class="' . esc_attr($like_class) . '" data-post-id="' . esc_attr($post_id) . '"><img src="' . esc_attr(plugin_dir_url(__FILE__) . 'assets/images/like.png') . '" alt="Like"></button>';
        echo '<span class="sorting-table-likes">' . esc_html($likes) . '</span>';
        echo '<button class="' . esc_attr($dislike_class) . '" data-post-id="' . esc_attr($post_id) . '"><img src="' . esc_attr(plugin_dir_url(__FILE__) . 'assets/images/dislike.png') . '" alt="Dislike"></button>';
        echo '<span class="sorting-table-dislikes">' . esc_html($dislikes) . '</span>';
        echo '</div>';
    }
}

// Učitavanje skripte za rukovanje klikovima na dugmad
function sorting_table_enqueue_scripts() {
    wp_enqueue_script('sorting-table-script', plugin_dir_url(__FILE__) . 'assets/js/script.js', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'sorting_table_enqueue_scripts');
