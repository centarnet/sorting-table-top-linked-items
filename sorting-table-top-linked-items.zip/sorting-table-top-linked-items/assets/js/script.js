// script.js

(function($) {
  // Funkcija koja se izvršava nakon što se učita cijela stranica
  $(document).ready(function() {
    // Dodavanje događaja klikanja na like dugme
    $('.sorting-table-like').on('click', function() {
      var postId = $(this).data('post-id');
      likePost(postId);
    });

    // Dodavanje događaja klikanja na dislike dugme
    $('.sorting-table-dislike').on('click', function() {
      var postId = $(this).data('post-id');
      dislikePost(postId);
    });
  });

  // Funkcija za lajkovanje posta
  function likePost(postId) {
    // Ajax zahtjev za lajkovanje posta
    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: {
        action: 'sorting_table_like_post',
        post_id: postId,
      },
      success: function(response) {
        // Osvježavanje brojača lajkova
        $('.sorting-table-likes[data-post-id="' + postId + '"]').text(response.likes);

        // Onemogućavanje like dugmeta i omogućavanje dislike dugmeta
        $('.sorting-table-like[data-post-id="' + postId + '"]').addClass('disabled active');
        $('.sorting-table-dislike[data-post-id="' + postId + '"]').removeClass('disabled active');
      },
    });
  }

  // Funkcija za dislikeovanje posta
  function dislikePost(postId) {
    // Ajax zahtjev za dislikeovanje posta
    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: {
        action: 'sorting_table_dislike_post',
        post_id: postId,
      },
      success: function(response) {
        // Osvježavanje brojača dislikeova
        $('.sorting-table-dislikes[data-post-id="' + postId + '"]').text(response.dislikes);

        // Onemogućavanje dislike dugmeta i omogućavanje like dugmeta
        $('.sorting-table-like[data-post-id="' + postId + '"]').removeClass('disabled active');
        $('.sorting-table-dislike[data-post-id="' + postId + '"]').addClass('disabled active');
      },
    });
  }
})(jQuery);
