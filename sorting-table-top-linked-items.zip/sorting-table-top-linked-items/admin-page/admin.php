<?php
// Funkcija za prikazivanje administratorske stranice za plugin
function sorting_table_settings_page() {
    ?>
    <div class="wrap">
        <h1>Sorting Table Settings</h1>
        <p>Here you can configure the settings for the Sorting Table plugin.</p>
        <form method="post" action="options.php">
            <?php
            // Dodavanje WordPress polja za unos opcija
            settings_fields('sorting_table_settings');
            do_settings_sections('sorting_table_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Funkcija za registraciju administratorskih opcija
function sorting_table_register_settings() {
    // Registracija opcija
    register_setting('sorting_table_settings', 'sorting_table_option_1');
    register_setting('sorting_table_settings', 'sorting_table_option_2');
    // Dodavanje sekcija i polja
    add_settings_section('sorting_table_section_1', 'Section 1', 'sorting_table_section_1_callback', 'sorting_table_settings');
    add_settings_field('sorting_table_field_1', 'Field 1', 'sorting_table_field_1_callback', 'sorting_table_settings', 'sorting_table_section_1');
    add_settings_field('sorting_table_field_2', 'Field 2', 'sorting_table_field_2_callback', 'sorting_table_settings', 'sorting_table_section_1');
}
add_action('admin_init', 'sorting_table_register_settings');

// Callback funkcija za prikazivanje sekcije
function sorting_table_section_1_callback() {
    echo '<p>Section 1 description.</p>';
}

// Callback funkcija za prikazivanje polja 1
function sorting_table_field_1_callback() {
    $value = get_option('sorting_table_option_1');
    echo '<input type="text" name="sorting_table_option_1" value="' . esc_attr($value) . '">';
}

// Callback funkcija za prikazivanje polja 2
function sorting_table_field_2_callback() {
    $value = get_option('sorting_table_option_2');
    echo '<textarea name="sorting_table_option_2">' . esc_textarea($value) . '</textarea>';
}

// Dodavanje administratorske stranice u izbornik
function sorting_table_add_settings_page() {
    add_submenu_page(
        'tools.php', // Roditeljska stranica u izborniku (Tools)
        'Sorting Table Settings', // Naziv stranice u izborniku
        'Sorting Table', // Naziv stavke u izborniku
        'manage_options', // Potrebne administratorske ovlasti
        'sorting-table-settings', // Unikatni identifikator stranice
        'sorting_table_settings_page' // Callback funkcija za prikaz stranice
    );
}
add_action('admin_menu', 'sorting_table_add_settings_page');
