<?php
// database.php

// Stvaranje baze podataka plugin-a
function create_plugin_database() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'sorting_table';

    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") !== $table_name) {
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            post_id mediumint(9) NOT NULL,
            likes mediumint(9) DEFAULT 0,
            dislikes mediumint(9) DEFAULT 0,
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}

// Brisanje baze podataka plugin-a
function delete_plugin_database() {
    global $wpdb;

    $table_name = $wpdb->prefix . 'sorting_table';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}
