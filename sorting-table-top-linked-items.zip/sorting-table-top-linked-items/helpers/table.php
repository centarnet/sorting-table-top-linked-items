<?php
// table.php

// Funkcija za sortiranje tablice po broju likeova
function sorting_table_sort_table($query) {
    if (!is_admin()) {
        return $query;
    }

    if ($query->get('orderby') === 'likes') {
        $query->set('meta_key', 'likes');
        $query->set('orderby', 'meta_value_num');
    }

    return $query;
}
add_action('pre_get_posts', 'sorting_table_sort_table');

// Funkcija za ažuriranje broja likeova i dislikeova pri sortiranju tablice
function sorting_table_update_likes_on_sort($posts, $query) {
    if (!is_admin()) {
        return $posts;
    }

    if ($query->get('orderby') === 'likes') {
        foreach ($posts as $post) {
            $likes = get_post_meta($post->ID, 'likes', true);
            $dislikes = get_post_meta($post->ID, 'dislikes', true);
            $post->likes = $likes;
            $post->dislikes = $dislikes;
        }
    }

    return $posts;
}
add_filter('the_posts', 'sorting_table_update_likes_on_sort', 10, 2);
